var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/leads-export.ts
var leads_export_exports = {};
__export(leads_export_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(leads_export_exports);

// netlify/functions/lib/auth.ts
var import_node_crypto = require("crypto");
var JSON_HEADERS = {
  "Content-Type": "application/json",
  "Cache-Control": "no-store, no-cache, must-revalidate",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer"
};
function getAdminAccessKey() {
  return (process.env.ADMIN_ACCESS_KEY || "").trim();
}
function safeSecretMatch(candidate, expected) {
  const candidateBytes = Buffer.from(candidate, "utf8");
  const expectedBytes = Buffer.from(expected, "utf8");
  return candidateBytes.length === expectedBytes.length && (0, import_node_crypto.timingSafeEqual)(candidateBytes, expectedBytes);
}
function verifyAdminAccess(event) {
  const adminAccessKey = getAdminAccessKey();
  if (!adminAccessKey) {
    return {
      authorized: false,
      status: 503,
      error: "Server configuration error: ADMIN_ACCESS_KEY is not configured on the server. Administrative access is locked."
    };
  }
  const headers = event.headers || {};
  const authHeader = headers["authorization"] || headers["Authorization"] || "";
  const bearerKey = authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : "";
  const customHeaderKey = (headers["x-admin-key"] || headers["X-Admin-Key"] || "").trim();
  if (bearerKey && safeSecretMatch(bearerKey, adminAccessKey) || customHeaderKey && safeSecretMatch(customHeaderKey, adminAccessKey)) {
    return { authorized: true, status: 200 };
  }
  return {
    authorized: false,
    status: 401,
    error: "Unauthorized access. Valid administrator key required in Authorization or X-Admin-Key header."
  };
}
function errorResponse(status, message) {
  return {
    statusCode: status,
    headers: JSON_HEADERS,
    body: JSON.stringify({ success: false, error: message })
  };
}

// netlify/functions/lib/db.ts
function isDatabaseConfigured() {
  const url = (process.env.SUPABASE_URL || "").trim().replace(/\/$/, "");
  const key = (process.env.SUPABASE_SERVICE_ROLE_KEY || "").trim();
  return Boolean(url && key);
}
function databaseHeaders(extra = {}) {
  const url = (process.env.SUPABASE_URL || "").trim().replace(/\/$/, "");
  const key = (process.env.SUPABASE_SERVICE_ROLE_KEY || "").trim();
  if (!url || !key) {
    throw new Error("Persistent subscriber storage is not configured.");
  }
  return {
    // Supabase sb_secret_* keys are opaque API keys, not JWTs. Send only via apikey.
    apikey: key,
    "Content-Type": "application/json",
    Accept: "application/json",
    ...extra
  };
}
async function databaseRequest(tablePath, init = {}) {
  const url = (process.env.SUPABASE_URL || "").trim().replace(/\/$/, "");
  const response = await fetch(`${url}/rest/v1/${tablePath}`, {
    ...init,
    headers: databaseHeaders(init.headers || {})
  });
  if (!response.ok) {
    console.error("[Database] Supabase request failed:", response.status);
    throw new Error(`Persistent storage request failed (${response.status}).`);
  }
  if (response.status === 204) return void 0;
  return response.json();
}
async function listSubscribersFromDatabase() {
  const rows = await databaseRequest(
    "subscribers?select=id,name,email,signup_date,source,marketing_consent,consent_date,sender_synced&order=signup_date.desc"
  );
  return (rows || []).map((row) => ({
    id: String(row.id),
    name: row.name || "Reader",
    email: row.email || "",
    date: row.signup_date || row.created_at || "",
    source: row.source || "ebook_lead_modal",
    marketingConsent: Boolean(row.marketing_consent),
    consentDate: row.consent_date || null,
    senderSynced: Boolean(row.sender_synced)
  }));
}

// netlify/functions/leads-export.ts
function csvCell(value) {
  let text = String(value ?? "");
  if (/^\s*[=+\-@]/.test(text) || /^[\t\r]/.test(text)) text = "'" + text;
  return `"${text.replace(/"/g, '""')}"`;
}
var handler = async (event) => {
  if (event.httpMethod !== "GET") return errorResponse(405, "Method not allowed. Expected GET.");
  const auth = verifyAdminAccess(event);
  if (!auth.authorized) return errorResponse(auth.status, auth.error || "Unauthorized access.");
  if (!isDatabaseConfigured()) return errorResponse(503, "Persistent subscriber database is not configured.");
  try {
    const subscribers = await listSubscribersFromDatabase();
    const header = ["ID", "Name", "Email", "Date Requested", "Source", "Marketing Consent", "Consent Date", "Sender Synced"];
    const rows = subscribers.map((sub) => [
      csvCell(sub.id),
      csvCell(sub.name),
      csvCell(sub.email),
      csvCell(sub.date),
      csvCell(sub.source),
      csvCell(sub.marketingConsent ? "Yes" : "No"),
      csvCell(sub.consentDate || "N/A"),
      csvCell(sub.senderSynced ? "Yes" : "No")
    ]);
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": 'attachment; filename="everyday_gut_wellness_subscribers.csv"',
        "Cache-Control": "no-store, no-cache, must-revalidate",
        "X-Content-Type-Options": "nosniff"
      },
      body: [header.join(","), ...rows.map((row) => row.join(","))].join("\n") + "\n"
    };
  } catch {
    return errorResponse(503, "Unable to export subscriber records. Please try again.");
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
