var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/subscribe.ts
var subscribe_exports = {};
__export(subscribe_exports, {
  config: () => config,
  handler: () => handler
});
module.exports = __toCommonJS(subscribe_exports);

// netlify/functions/lib/auth.ts
var import_node_crypto = require("crypto");
var JSON_HEADERS = {
  "Content-Type": "application/json",
  "Cache-Control": "no-store, no-cache, must-revalidate",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer"
};
function errorResponse(status, message) {
  return {
    statusCode: status,
    headers: JSON_HEADERS,
    body: JSON.stringify({ success: false, error: message })
  };
}
function jsonResponse(status, data) {
  return {
    statusCode: status,
    headers: JSON_HEADERS,
    body: JSON.stringify(data)
  };
}

// netlify/functions/lib/db.ts
function isDatabaseConfigured() {
  const url = (process.env.SUPABASE_URL || "").trim().replace(/\/$/, "");
  const key = (process.env.SUPABASE_SERVICE_ROLE_KEY || "").trim();
  return Boolean(url && key);
}
function databaseHeaders(extra = {}) {
  const url = (process.env.SUPABASE_URL || "").trim().replace(/\/$/, "");
  const key = (process.env.SUPABASE_SERVICE_ROLE_KEY || "").trim();
  if (!url || !key) {
    throw new Error("Persistent subscriber storage is not configured.");
  }
  return {
    // Supabase sb_secret_* keys are opaque API keys, not JWTs. Send only via apikey.
    apikey: key,
    "Content-Type": "application/json",
    Accept: "application/json",
    ...extra
  };
}
async function databaseRequest(tablePath, init = {}) {
  const url = (process.env.SUPABASE_URL || "").trim().replace(/\/$/, "");
  const response = await fetch(`${url}/rest/v1/${tablePath}`, {
    ...init,
    headers: databaseHeaders(init.headers || {})
  });
  if (!response.ok) {
    console.error("[Database] Supabase request failed:", response.status);
    throw new Error(`Persistent storage request failed (${response.status}).`);
  }
  if (response.status === 204) return void 0;
  return response.json();
}
async function saveSubscriber(input) {
  const payload = {
    name: input.name,
    email: input.email,
    source: input.source
  };
  if (input.marketingConsent) {
    payload.marketing_consent = true;
    payload.consent_date = (/* @__PURE__ */ new Date()).toISOString();
    payload.consent_withdrawn_at = null;
  }
  const rows = await databaseRequest("subscribers?on_conflict=email", {
    method: "POST",
    headers: { Prefer: "resolution=merge-duplicates,return=representation" },
    body: JSON.stringify(payload)
  });
  const row = rows?.[0];
  if (!row?.id) throw new Error("Database did not confirm that the signup was saved.");
  return {
    id: String(row.id),
    name: row.name || "Reader",
    email: row.email,
    date: row.signup_date || row.created_at || (/* @__PURE__ */ new Date()).toISOString(),
    source: row.source || input.source,
    marketingConsent: Boolean(row.marketing_consent),
    consentDate: row.consent_date || null,
    senderSynced: Boolean(row.sender_synced)
  };
}
async function markSenderSync(id, success, errorMessage) {
  await databaseRequest(`subscribers?id=eq.${encodeURIComponent(id)}`, {
    method: "PATCH",
    headers: { Prefer: "return=minimal" },
    body: JSON.stringify({
      sender_synced: success,
      sender_synced_at: success ? (/* @__PURE__ */ new Date()).toISOString() : null,
      sender_sync_error: success ? null : (errorMessage || "Sender.net sync failed").slice(0, 300)
    })
  });
}

// netlify/functions/subscribe.ts
var EMAIL_REGEX = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
var MAX_REQUEST_BYTES = 16384;
var ALLOWED_SOURCES = /* @__PURE__ */ new Set(["ebook_lead_modal", "planner_interest_list"]);
var config = {
  path: "/api/subscribe",
  rateLimit: { windowSize: 60, windowLimit: 5, aggregateBy: ["ip"] }
};
var handler = async (event) => {
  if (event.httpMethod !== "POST") return errorResponse(405, "Method not allowed. Expected POST.");
  if (!isDatabaseConfigured()) return errorResponse(503, "Email signup is temporarily unavailable. Please try again shortly.");
  if (!event.body) return errorResponse(400, "A signup request is required.");
  if (Buffer.byteLength(event.body, "utf8") > MAX_REQUEST_BYTES) return errorResponse(413, "The signup request is too large.");
  let body;
  try {
    body = JSON.parse(event.body);
    if (!body || typeof body !== "object" || Array.isArray(body)) return errorResponse(400, "Invalid JSON request payload.");
  } catch {
    return errorResponse(400, "Invalid JSON request payload.");
  }
  if (typeof body.email !== "string") return errorResponse(400, "Please provide a valid email address.");
  const email = body.email.trim().toLowerCase();
  if (email.length > 254 || !EMAIL_REGEX.test(email)) return errorResponse(400, "Please provide a valid email address.");
  const rawName = typeof body.name === "string" ? body.name : "Reader";
  const name = rawName.replace(/[\u0000-\u001F\u007F]/g, " ").replace(/<[^>]*>?/gm, "").trim().slice(0, 80) || "Reader";
  const requestedSource = typeof body.source === "string" ? body.source : "ebook_lead_modal";
  const source = ALLOWED_SOURCES.has(requestedSource) ? requestedSource : "ebook_lead_modal";
  const marketingConsent = body.marketingConsent === true;
  try {
    const subscriber = await saveSubscriber({ name, email, source, marketingConsent });
    let senderSynced = false;
    let senderStatus = "Saved securely. Email marketing sync is not configured.";
    const token = (process.env.SENDER_API_TOKEN || "").trim();
    const groupId = (process.env.SENDER_GROUP_ID || "").trim();
    if (marketingConsent && token) {
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 8e3);
        let senderResponse;
        try {
          senderResponse = await fetch("https://api.sender.net/v2/subscribers", {
            method: "POST",
            signal: controller.signal,
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
              Accept: "application/json"
            },
            body: JSON.stringify({ email, firstname: name, ...groupId ? { groups: [groupId] } : {} })
          });
        } finally {
          clearTimeout(timeout);
        }
        senderSynced = senderResponse.ok;
        senderStatus = senderSynced ? "Saved and synced to the opted-in email list." : "Saved securely; email platform sync needs attention.";
        if (!senderSynced) await markSenderSync(subscriber.id, false, `Sender.net returned ${senderResponse.status}`);
        else await markSenderSync(subscriber.id, true);
      } catch (error) {
        senderStatus = "Saved securely; email platform sync will need a retry.";
        try {
          await markSenderSync(subscriber.id, false, "Sender.net request failed or timed out");
        } catch {
        }
        console.warn("[Lead capture] Sender.net sync failed:", error?.name || "request_error");
      }
    } else if (marketingConsent && !token) {
      senderStatus = "Saved securely; email marketing is awaiting platform configuration.";
    } else {
      senderStatus = "Saved securely. Marketing emails were not requested.";
    }
    return jsonResponse(200, {
      success: true,
      message: "Your free 7-Day Gentle Gut Reset Guide signup is ready.",
      subscriber: { name: subscriber.name, email: subscriber.email, marketingConsent: subscriber.marketingConsent },
      senderSynced,
      senderStatus
    });
  } catch (error) {
    console.error("[Netlify Function] Lead capture failed:", error?.message || "unknown_error");
    return errorResponse(503, "We couldn't securely save your signup just yet. Your email has not been added. Please try again.");
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config,
  handler
});
