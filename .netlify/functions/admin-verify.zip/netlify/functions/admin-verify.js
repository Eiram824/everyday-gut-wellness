var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/admin-verify.ts
var admin_verify_exports = {};
__export(admin_verify_exports, {
  config: () => config,
  handler: () => handler
});
module.exports = __toCommonJS(admin_verify_exports);

// netlify/functions/lib/auth.ts
var import_node_crypto = require("crypto");
var JSON_HEADERS = {
  "Content-Type": "application/json",
  "Cache-Control": "no-store, no-cache, must-revalidate",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer"
};
function getAdminAccessKey() {
  return (process.env.ADMIN_ACCESS_KEY || "").trim();
}
function safeSecretMatch(candidate, expected) {
  const candidateBytes = Buffer.from(candidate, "utf8");
  const expectedBytes = Buffer.from(expected, "utf8");
  return candidateBytes.length === expectedBytes.length && (0, import_node_crypto.timingSafeEqual)(candidateBytes, expectedBytes);
}
function errorResponse(status, message) {
  return {
    statusCode: status,
    headers: JSON_HEADERS,
    body: JSON.stringify({ success: false, error: message })
  };
}
function jsonResponse(status, data) {
  return {
    statusCode: status,
    headers: JSON_HEADERS,
    body: JSON.stringify(data)
  };
}

// netlify/functions/admin-verify.ts
var config = {
  path: "/api/admin/verify",
  rateLimit: { windowSize: 60, windowLimit: 10, aggregateBy: ["ip"] }
};
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return errorResponse(405, "Method not allowed. Expected POST.");
  }
  const configuredKey = getAdminAccessKey();
  if (!configuredKey) {
    return errorResponse(503, "Administrative access is currently unavailable.");
  }
  if (Buffer.byteLength(event.body || "", "utf8") > 4096) return errorResponse(413, "The request is too large.");
  try {
    const body = event.body ? JSON.parse(event.body) : {};
    if (!body || typeof body !== "object" || Array.isArray(body) || typeof body.key !== "string") {
      return errorResponse(400, "Invalid JSON request payload.");
    }
    const key = body.key.trim();
    if (key && safeSecretMatch(key, configuredKey)) {
      return jsonResponse(200, {
        success: true,
        message: "Admin authenticated."
      });
    }
    return errorResponse(401, "Invalid administrator key.");
  } catch {
    return errorResponse(400, "Invalid JSON request payload.");
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config,
  handler
});
