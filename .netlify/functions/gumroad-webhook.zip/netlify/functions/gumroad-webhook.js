var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/gumroad-webhook.ts
var gumroad_webhook_exports = {};
__export(gumroad_webhook_exports, {
  config: () => config,
  default: () => gumroad_webhook_default,
  handler: () => handler
});
module.exports = __toCommonJS(gumroad_webhook_exports);

// netlify/functions/lib/auth.ts
var import_node_crypto = require("crypto");
var JSON_HEADERS = {
  "Content-Type": "application/json",
  "Cache-Control": "no-store, no-cache, must-revalidate",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer"
};
function errorResponse(status, message) {
  return {
    statusCode: status,
    headers: JSON_HEADERS,
    body: JSON.stringify({ success: false, error: message })
  };
}
function jsonResponse(status, data) {
  return {
    statusCode: status,
    headers: JSON_HEADERS,
    body: JSON.stringify(data)
  };
}

// netlify/functions/lib/db.ts
function isDatabaseConfigured() {
  const url = (process.env.SUPABASE_URL || "").trim().replace(/\/$/, "");
  const key = (process.env.SUPABASE_SERVICE_ROLE_KEY || "").trim();
  return Boolean(url && key);
}

// netlify/functions/gumroad-webhook.ts
var config = {
  path: "/api/gumroad-webhook"
};
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return errorResponse(405, "Method not allowed. Expected POST.");
  }
  const webhookSecret = (process.env.GUMROAD_WEBHOOK_SECRET || "").trim();
  if (webhookSecret) {
    const signature = event.headers["x-gumroad-signature"] || event.headers["x-signature"];
    if (!signature || signature !== webhookSecret) {
      return errorResponse(401, "Unauthorized webhook request.");
    }
  }
  if (!event.body) {
    return errorResponse(400, "Webhook payload is empty.");
  }
  let data;
  try {
    if (event.headers["content-type"]?.includes("application/json")) {
      data = JSON.parse(event.body);
    } else {
      const params = new URLSearchParams(event.body);
      data = Object.fromEntries(params.entries());
    }
  } catch (err) {
    return errorResponse(400, "Invalid webhook body.");
  }
  const email = (data.email || "").trim().toLowerCase();
  const productId = data.product_id || data.permalink || "";
  const productName = data.product_name || "Gut Workbook";
  const saleId = data.sale_id || data.order_number || "";
  const pricePaid = data.price ? Number(data.price) / 100 : 0;
  if (!email) {
    return errorResponse(400, "Buyer email is missing in webhook payload.");
  }
  console.info(`[Gumroad Webhook] Received sale for product: ${productName}, email: ${email.substring(0, 3)}***`);
  let supabaseUpdated = false;
  let systemeSynced = false;
  const supabaseUrl = (process.env.SUPABASE_URL || "").trim().replace(/\/$/, "");
  const supabaseKey = (process.env.SUPABASE_SERVICE_ROLE_KEY || "").trim();
  if (isDatabaseConfigured() && supabaseUrl && supabaseKey) {
    try {
      const response = await fetch(`${supabaseUrl}/rest/v1/subscribers?email=eq.${encodeURIComponent(email)}`, {
        method: "PATCH",
        headers: {
          apikey: supabaseKey,
          "Content-Type": "application/json",
          Prefer: "return=representation"
        },
        body: JSON.stringify({
          is_buyer: true,
          purchased_workbook: true,
          last_purchase_product: productName,
          last_purchase_at: (/* @__PURE__ */ new Date()).toISOString(),
          promo_exclusion_tag: true
        })
      });
      supabaseUpdated = response.ok;
      if (!response.ok) {
        const insertRes = await fetch(`${supabaseUrl}/rest/v1/subscribers`, {
          method: "POST",
          headers: {
            apikey: supabaseKey,
            "Content-Type": "application/json",
            Prefer: "resolution=merge-duplicates"
          },
          body: JSON.stringify({
            email,
            name: data.full_name || data.name || "Workbook Buyer",
            source: "gumroad_purchase",
            is_buyer: true,
            purchased_workbook: true,
            promo_exclusion_tag: true,
            signup_date: (/* @__PURE__ */ new Date()).toISOString()
          })
        });
        supabaseUpdated = insertRes.ok;
      }
    } catch (err) {
      console.warn("[Gumroad Webhook] Supabase buyer tag update failed:", err?.message);
    }
  }
  const systemeApiKey = (process.env.SYSTEME_IO_API_KEY || "").trim();
  const systemeTagId = (process.env.SYSTEME_IO_BUYER_TAG_ID || "").trim();
  if (systemeApiKey) {
    try {
      const sysRes = await fetch("https://api.systeme.io/api/v1/contacts", {
        method: "POST",
        headers: {
          "X-API-Key": systemeApiKey,
          "Content-Type": "application/json",
          Accept: "application/json"
        },
        body: JSON.stringify({
          email,
          ...systemeTagId ? { tagIds: [systemeTagId] } : {},
          fields: [{ slug: "purchased_product", value: productName }]
        })
      });
      systemeSynced = sysRes.ok;
    } catch (err) {
      console.warn("[Gumroad Webhook] Systeme.io sync failed:", err?.message);
    }
  }
  return jsonResponse(200, {
    received: true,
    email,
    productId,
    supabaseUpdated,
    systemeSynced,
    message: "Gumroad sale processed successfully. Buyer tagged for promotional exclusion."
  });
};
var gumroad_webhook_default = handler;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config,
  handler
});
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
